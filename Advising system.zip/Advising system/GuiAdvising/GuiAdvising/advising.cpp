#include "advising.h"
#include <iostream>
#include<iostream>
#include <string>
#include <iomanip>
#include<fstream>
#include<string>
using namespace std;


advising::advising() {
    string name="hbrie";
    int ID=567 ;
    //string arr[7][7];
};
advising::advising(string name, int id) {
    string Name = name;
    int ID = id;
};
string advising::Temp() {
    string id;
    fstream fil;
    fil.open("temp.txt");
    getline(fil, id);
    return id;
}



void advising::writescheduletofile(string x)
{
    string id;
    fstream fil;
    fil.open("temp.txt");
    getline(fil, id);
    string hh;
    fstream fun;
    fun.open(id + ".txt", std::ios_base::app);
    fun << x;
};

void advising:: FileToArray(string Slots[12],string id) {
    //string Slots[24];
    
    fstream fil;
    /*fil.open("temp.txt");
    getline(fil, id);*/
    fstream Tim;
    Tim.open(id + ".txt");
    int i = 0;
    for (int i = 0; i < 12; i++) {
        string s;
        getline(Tim, s);
        Slots[i] = s;
    }
}

void advising::Generate (string gadwal[10], string dataStructure[12], string DataBase[12], string oop[12], string CO[12], string SOC[12],string openfile) {
   
        int mat, prog, eng, prob, eth, count = 0;
        /*string math[12] = { "s 8-10","s 1-3","mon 8-10","mon 4-6","tue 2-3","tue 9-10","wed 1-3","wed 8-10","thu 3-4","thu 6-7" };
        string programming[12] = { "s 8-10","s 2-4","mon 8-4","mon 4-5","tue 1-3","tue 2-10","wed 7-3","wed 1-10","thu 3-3","thu 6-8" };
        string english[12] = { "s 8-11","s 5-3","mond 8-10","mond 4-6","tues 2-3","tuee 9-10","wed 2-3","wed 8-10","thur 3-4","thu 6-7" };
        string probability[12] = { "s 8=11","s 5=3","mond 8-10","mon 4=6","tues 2=3","tuee 9=10","wed 2=3","wed 8=10","thur 3=4","thur 6-7" };
        string ethics[12] = { "s 18=11","s 15=3","mon 8-10","mon 14=6","tues 21=3","tuee 19=10","wed 12=3","wed 18=10","thur 13=4","thur 6-7" };*/
        static int call_count = 0;
        srand((unsigned)time(0) + call_count);
        call_count++;
        while (count < 1) {
            mat = rand() % 13;
            prog = rand() % 13;
            eng = rand() % 13;
            prob = rand() % 13;
            eth = rand() % 13;
            if (dataStructure[mat] != DataBase[prog] && dataStructure[mat] != oop[eng] && dataStructure[mat] != CO[prob] && dataStructure[mat] !=SOC[eth]
                && DataBase[prog] != oop[eng] && DataBase[prog] != CO[prob] && DataBase[prog] != SOC[eth]
                && oop[eng] != CO[prob] && oop[eng] != SOC[eth]
                && CO[prob] != SOC[eth]) {
                gadwal[1] = dataStructure[mat];
                gadwal[3] = DataBase[prog];
                gadwal[5] = oop[eng];
                gadwal[7] = CO[prob];
                gadwal[9] = SOC[eth];
                gadwal[0] = "Data Structures & Algorithms";
                gadwal[2] = "Database Management Systems";
                gadwal[4] = "Object Oriented Programming";
                gadwal[6] = "Computer Organization";
                gadwal[8] = "computer application";
                    

                count++;

            }
            /*for (int i = 0; i < 5; i++) {
                cout << gadwal[i] << endl;
            }*/

        }
        fstream file;
        

        file.open(openfile+".txt", std::ios_base::app);
        if (file.is_open()) {
            for (int i = 0; i < 10; i++)
            {
                file << gadwal[i] << endl;
            }
            file.close();
        }
    }
void advising::GenerateToFile(string schedule[5]) {
    
        fstream file;
        file.open("202299999.txt");
        if (file.is_open()) {
            for (int i = 0; i < 5; i++)
            {
                file << schedule[i] << endl;
            }
            file.close();
        }

 }

string advising::coursename(string id) {
    if (id == "202202798")
        return "programming";
    else if (id == "202204444")
        return "Math";
    else if (id == "202201234")
        return "probability";
    else if (id == "202206738")
        return "Physics";
    else if (id == "202299999")
        return "Data Structure";
}










   



    //int advising::search(string array[][7], int row, int j, int i)
    //{
    //    return 0;
    //}
